/* DIVINA BRUXA 4.0 — ORBE SUPREMA 2.0 + WORK12 CÂMARAS V596
   Toda realidade possui altar físico estável. Mundos em que a Orbe executa
   uma função própria são construídos antes do commit visual da rota.
   Escola e Diário respeitam a autoridade do limiar único V596. */

import {
  normalizeRouteId,
  routeHasModule,
  routeLabel,
  routeNeedsPortalStyles
} from './route-registry-v180.js?v=300';
import { connectTarotMesaBridgeV517 } from './tarot-mesa-bridge-v517.js?v=517';

const pageTasks = new Map();
const sharedTasks = new Map();
const LOAD_TIMEOUT_MS = 15000;
export const NAVIGATION_PREPARE_BUDGET_MS_V535 = 48;
/* A viagem só cruza o portal depois que a realidade definitiva existe. Assim
   nenhum mundo troca o altar sob a Orbe depois do pouso. */
const ARRIVAL_CRITICAL_ROUTES_V577 = new Set([
  'tarot','daily','library','school','ai','journal'
]);
const PORTAL_STYLES_ID = 'divinaPortalStylesV180';
const PORTAL_STYLES_HREF = 'divina-core-v179.css?v=179';
let loadingSequence = 0;

function once(map,key,factory){
  if(map.has(key)) return map.get(key);
  const task=Promise.resolve().then(factory).catch(error=>{
    map.delete(key);
    throw error;
  });
  map.set(key,task);
  return task;
}
function withTimeout(task,timeout,message){
  let timer=0;
  return Promise.race([
    Promise.resolve(task),
    new Promise((_,reject)=>{ timer=setTimeout(()=>reject(new Error(message)),timeout); })
  ]).finally(()=>clearTimeout(timer));
}
const wait=milliseconds=>new Promise(resolve=>setTimeout(resolve,Math.max(0,milliseconds)));
function ensureStyle(id,href){
  return once(sharedTasks,`style:${id}`,()=>withTimeout(new Promise((resolve,reject)=>{
    let link=document.getElementById(id);
    if(link?.sheet){ resolve(link); return; }
    if(link) link.remove();
    link=document.createElement('link');
    link.id=id;
    link.rel='stylesheet';
    link.href=href;
    link.dataset.rebirthStyle='true';
    link.addEventListener('load',()=>resolve(link),{once:true});
    link.addEventListener('error',()=>reject(new Error(`Estilo indisponível: ${href}`)),{once:true});
    document.head.append(link);
  }),LOAD_TIMEOUT_MS,`Tempo esgotado ao carregar ${href}.`));
}

// CSS e módulo continuam carregando em paralelo, mas o módulo passa a ser
// identificado pela sua posição final em um único contrato. Isso impede que a
// adição de uma folha de estilo transforme acidentalmente um <link> em módulo.
export async function loadModuleAfterStylesV562(styleTasks=[],moduleTask){
  const tasks=Array.isArray(styleTasks)?styleTasks:[styleTasks];
  const results=await Promise.all([...tasks,moduleTask]);
  const loadedModule=results[results.length-1];
  if(!loadedModule||!['object','function'].includes(typeof loadedModule)){
    throw new TypeError('module_load_invalid_v562');
  }
  return loadedModule;
}
function ensureImage(href){
  return once(sharedTasks,`image:${href}`,()=>new Promise(resolve=>{
    const image=new Image();
    let settled=false;
    const finish=value=>{
      if(settled)return;
      settled=true;
      clearTimeout(timer);
      resolve(value);
    };
    const timer=setTimeout(()=>finish(false),5200);
    image.decoding='async';
    image.fetchPriority='high';
    image.addEventListener('load',async()=>{
      try{await image.decode?.();}catch{}
      finish(image.naturalWidth>0);
    },{once:true});
    image.addEventListener('error',()=>finish(false),{once:true});
    image.src=href;
  }));
}
function loadPortalStyles(){
  return ensureStyle(PORTAL_STYLES_ID,PORTAL_STYLES_HREF);
}
function announceLoading(type,detail){
  document.dispatchEvent(new CustomEvent(`divina:loading-${type}`,{detail}));
}
function createRecovery(screen,id){
  if(!screen||screen.querySelector(':scope > [data-route-recovery]')) return;
  const panel=document.createElement('aside');
  panel.className='db-route-recovery';
  panel.dataset.routeRecovery=id;
  panel.setAttribute('role','alert');
  panel.setAttribute('aria-live','assertive');
  panel.innerHTML=`<span class="db-route-recovery__sigil" aria-hidden="true">✦</span><h3>Este mundo não abriu por completo</h3><p>Nada foi perdido.</p><div><button type="button" data-route-retry="${id}">TENTAR NOVAMENTE</button><button type="button" class="secondary" data-go="home">VOLTAR À ORBE</button></div>`;
  screen.prepend(panel);
}
function clearRecovery(screen){
  screen?.querySelector(':scope > [data-route-recovery]')?.remove();
}

const LOADING_MESSAGES=Object.freeze({
  tarot:'A Orbe abre o círculo…',
  daily:'A Orbe encontra a carta deste dia…',
  library:'Abrindo as 78 cartas…',
  spreads:'Preparando sua tiragem…',
  school:'Abrindo a Escola…',
  journal:'Abrindo seu espaço privado…',
  ai:'Whit está abrindo este espaço…',
  store:'Abrindo a Loja Mística…',
  consultations:'Abrindo Consultas…',
  music:'Abrindo Música…',
  videos:'Abrindo Vídeos…',
  skins:'Vestindo a Orbe…'
});

export function createPageLoader({config,go,authClient=globalThis.divinaAuth}={}){
  const $=selector=>document.querySelector(selector);
  const abort=new AbortController();
  let observer=null;
  let deferredRoute=null;
  let deferredFrame=0;
  let deferredTimer=0;

  const ensureJournal=()=>once(sharedTasks,'journal',async()=>{
    const module=await loadModuleAfterStylesV562([
      ensureStyle('divinaJournalRebirthV317','journal-world-v317.css?v=556'),
      ensureStyle('divinaJournalMirrorSupremeV556','journal-mirror-supreme-v556.css?v=556')
    ],import('./journal-world-v317.js?v=596-work12-chambers'));
    const instance=new module.JournalWorldV317($('#journalApp'),{orbCore:globalThis.divinaOrbSupremeV501?.core||globalThis.orbe?.supreme});
    globalThis.divinaJournalWorldV317=instance;
    return instance;
  });
  const remember=entry=>ensureJournal().then(journal=>journal?.add?.(entry)).catch(()=>{});

  const ensureCommerce=()=>once(sharedTasks,'commerce',async()=>{
    const {CommerceEngine}=await import('./commerce-engine.js?v=148');
    return new CommerceEngine({
      store:$('#storeApp'),
      consultations:$('#consultationApp'),
      subscriptions:$('#subscriptionApp')
    },config);
  });

  const ensureMedia=()=>once(sharedTasks,'media',async()=>{
    const module=await loadModuleAfterStylesV562([
      ensureStyle('divinaMusicVideoSupremeV559','music-video-supreme-v559.css?v=559')
    ],import('./music-video-supreme-v559.js?v=559'));
    const instance=new module.MusicVideoSupremeV559({videos:$('#videoApp'),music:$('#musicApp')},config);
    globalThis.divinaMusicVideoSupremeV559=instance;
    return instance;
  });

  const loaders=Object.freeze({
    tarot: async()=>{
      const current=globalThis.divinaTarotLivreV517;
      if(current?.foundationRelease===576&&current.root===$('#tarot')&&!current.destroyed){
        return current;
      }
      current?.destroy?.();
      delete globalThis.divinaTarotLivreV517;
      // Retira somente estilos antigos. Os arquivos V500 permanecem seguros e inertes.
      globalThis.divinaFreeTarotV345?.destroy?.();
      delete globalThis.divinaFreeTarotV345;
      globalThis.divinaTarotLivreV503?.destroy?.();
      delete globalThis.divinaTarotLivreV503;
      globalThis.divinaTarotLivreV504?.destroy?.();
      delete globalThis.divinaTarotLivreV504;
      globalThis.divinaTarotLivreV505?.destroy?.();
      delete globalThis.divinaTarotLivreV505;
      globalThis.divinaTarotLivreV506?.destroy?.();
      delete globalThis.divinaTarotLivreV506;
      globalThis.divinaTarotLivreV507?.destroy?.();
      delete globalThis.divinaTarotLivreV507;
      globalThis.divinaTarotLivreV508?.destroy?.();
      delete globalThis.divinaTarotLivreV508;
      globalThis.divinaTarotLivreV510?.destroy?.();
      delete globalThis.divinaTarotLivreV510;
      globalThis.divinaTarotLivreV512?.destroy?.();
      delete globalThis.divinaTarotLivreV512;
      globalThis.divinaTarotLivreV513?.destroy?.();
      delete globalThis.divinaTarotLivreV513;
      globalThis.divinaTarotLivreV514?.destroy?.();
      delete globalThis.divinaTarotLivreV514;
      globalThis.divinaTarotLivreV515?.destroy?.();
      delete globalThis.divinaTarotLivreV515;
      globalThis.divinaTarotLivreV516?.destroy?.();
      delete globalThis.divinaTarotLivreV516;
      [
        'freeTarotFireEngineV345Styles',
        'divinaTarotLivreCosmicoV500',
        'divinaTarotLivreChamaV401',
        'divinaTarotLivreZeroV400',
        'divinaTarotRebirthV301',
        'divinaTarotLivreSupremoV503',
        'divinaTarotLivreSupremoV504',
        'divinaTarotLivreSupremoV505',
        'divinaTarotLivreSupremoV506',
        'divinaTarotLivreSupremoV507',
        'divinaTarotLivreSupremoV508',
        'divinaTarotLivreSupremoV510',
        'divinaTarotLivreOrbOSV512',
        'divinaTarotLivreOrbOSV513',
        'divinaTarotLivreOrbOSV514',
        'divinaTarotLivreOrbOSV515',
        'divinaTarotLivreOrbOSV516'
      ].forEach(styleId=>document.getElementById(styleId)?.remove());
      const module=await loadModuleAfterStylesV562([
        ensureStyle('divinaTarotLivreOrbOSV517','tarot-livre-orbe-os-v517.css?v=538-fluid'),
        ensureStyle('divinaTarotFreeSupremeV553','tarot-free-supreme-v553.css?v=553')
      ],import('./tarot-livre-orbe-os-v517.js?v=576-foundation'));
      const instance=new module.TarotLivreOrbOSV517($('#tarot'),{
        orbCore:globalThis.divinaOrbSupremeV501?.core||globalThis.orbe?.supreme
      });
      globalThis.divinaTarotLivreV517=instance;
      return instance;
    },
    daily: async()=>{
      globalThis.divinaDailyWorldV509?.destroy?.();
      delete globalThis.divinaDailyWorldV509;
      document.getElementById('divinaDailyRebirthV303')?.remove();
      const module=await loadModuleAfterStylesV562([
        ensureStyle('divinaDailyLivingV509','daily-world-v509.css?v=554'),
        ensureStyle('divinaDailySpreadsSupremeV554','daily-spreads-supreme-v554.css?v=554')
      ],import('./daily-world-v509.js?v=595-work12-ritual'));
      const instance=new module.DailyWorldV509($('#dailyCard'),{
        onSave:remember,
        authClient,
        orbCore:globalThis.divinaOrbSupremeV501?.core||globalThis.orbe?.supreme
      });
      globalThis.divinaDailyWorldV509=instance;
      return instance;
    },
    library: async()=>{
      const module=await loadModuleAfterStylesV562([
        ensureStyle('divinaLibraryRebirthV302','library-world-v302.css?v=555'),
        ensureStyle('divinaPublicLibraryV544','public-library-core-v544.css?v=555'),
        ensureStyle('divinaSchoolLibrarySupremeV555','school-library-supreme-v555.css?v=555')
      ],import('./library-world-v302.js?v=555'));
      const instance=new module.LibraryWorldV302($('#cardLibraryApp'),{onSave:remember,orbCore:globalThis.divinaOrbSupremeV501?.core||globalThis.orbe?.supreme});
      globalThis.divinaLibraryWorldV302=instance;
      return instance;
    },
    school: async()=>{
      const module=await loadModuleAfterStylesV562([
        ensureStyle('divinaSchoolRebirthV306','school-world-v306.css?v=555'),
        ensureStyle('divinaSchoolLibrarySupremeV555','school-library-supreme-v555.css?v=555')
      ],import('./school-world-v306.js?v=596-work12-chambers'));
      const instance=new module.SchoolWorldV306($('#schoolApp'),{authClient,orbCore:globalThis.divinaOrbSupremeV501?.core||globalThis.orbe?.supreme});
      globalThis.divinaSchoolWorldV306=instance;
      return instance;
    },
    spreads: async()=>{
      const module=await loadModuleAfterStylesV562([
        ensureStyle('divinaSpreadsRebirthV305','spreads-world-v305.css?v=554'),
        ensureStyle('divinaDailySpreadsSupremeV554','daily-spreads-supreme-v554.css?v=554')
      ],import('./spreads-world-v305.js?v=554'));
      const instance=new module.SpreadsWorldV305({
        grid:$('#spreadGrid'),
        result:$('#spreadResult'),
        intention:$('#spreadIntention'),
        history:$('#spreadHistory')
      },remember,{authClient,whit:globalThis.whit,orbCore:globalThis.divinaOrbSupremeV501?.core||globalThis.orbe?.supreme});
      globalThis.divinaSpreadsWorldV305=instance;
      connectTarotMesaBridgeV517(instance);
      return instance;
    },
    journal:ensureJournal,
    ai:async()=>{
      const module=await loadModuleAfterStylesV562([
        ensureStyle('divinaWhitPresenceDeepV540','whit-presence-deep-v540.css?v=557'),
        ensureStyle('divinaWhitLocalSupremeV557','whit-local-supreme-v557.css?v=557')
      ],import('./ai-engine.js?v=557'));
      const instance=new module.AIEngine($('#aiApp'),config,{authClient,orbCore:globalThis.divinaOrbSupremeV501?.core||globalThis.orbe?.supreme});
      globalThis.divinaWhitLocalV557=instance;
      return instance;
    },
    store:async()=>{
      await ensureCommerce();
      const module=await loadModuleAfterStylesV562([
        ensureStyle('divinaMediaCommerceRebirthV320','media-commerce-world-v320.css?v=320'),
        ensureStyle('divinaAmazonStoreV543','amazon-store-core-v543.css?v=543')
      ],import('./media-commerce-world-v320.js?v=543'));
      return new module.StoreWorldV320($('#storeApp'),config);
    },
    consultations:async()=>{
      await ensureCommerce();
      const module=await loadModuleAfterStylesV562([
        ensureStyle('divinaAccountConsultationsRebirthV319','account-consultations-world-v319.css?v=319'),
        ensureStyle('divinaConsultationsSupremeV558','consultations-supreme-v558.css?v=558')
      ],import('./account-consultations-world-v319.js?v=558-consultations-supreme'));
      return new module.ConsultationsWorldV319($('#consultationApp'),config);
    },
    subscriptions:async()=>{
      const module=await loadModuleAfterStylesV562([
        ensureStyle('divinaCrownRebirthV318','skins-premium-world-v318.css?v=546')
      ],import('./skins-premium-world-v318.js?v=546'));
      return new module.PremiumWorldV318($('#subscriptionApp'));
    },
    skins:async()=>{
      const module=await loadModuleAfterStylesV562([
        ensureStyle('divinaCrownRebirthV318','skins-premium-world-v318.css?v=546')
      ],import('./skins-premium-world-v318.js?v=546'));
      return new module.SkinsWorldV318($('#skinsApp'));
    },
    videos:ensureMedia,
    music:ensureMedia,
    notifications:async()=>{
      const module=await loadModuleAfterStylesV562([
        ensureStyle('divinaNotificationsRebirthV321','notifications-world-v321.css?v=321')
      ],import('./notifications-world-v321.js?v=321'));
      return new module.NotificationsWorldV321($('#notificationApp'),go);
    },
    admin:async()=>{
      const [,,,,,adminModule,mediaModule,intelligenceModule,observatoryModule,completionModule]=await Promise.all([
        ensureStyle('divinaMediaCommerceRebirthV320','media-commerce-world-v320.css?v=320'),
        ensureStyle('divinaMusicVideoSupremeV559','music-video-supreme-v559.css?v=559'),
        ensureStyle('divinaAdminIntelligenceRebirthV322','admin-intelligence-v322.css?v=322'),
        ensureStyle('divinaOwnerObservatoryV532Styles','owner-observatory-v532.css?v=548'),
        ensureStyle('divinaCompletionCenterV548Styles','completion-center-v548.css?v=548'),
        import('./admin-engine.js?v=548'),
        import('./admin-media-supreme-v559.js?v=559'),
        import('./admin-intelligence-v322.js?v=561'),
        import('./owner-observatory-v532.js?v=548'),
        import('./completion-center-v548.js?v=548')
      ]);
      const engine=new adminModule.AdminEngine($('#adminApp'));
      globalThis.divinaAdminMediaSupremeV559=new mediaModule.AdminMediaSupremeV559($('#adminApp'),config);
      new intelligenceModule.AdminIntelligenceV322($('#adminApp'));
      const completionCore=completionModule.createCompletionCenterV548($('#adminApp'),{orbCore:globalThis.divinaOrbSupremeV501?.core||globalThis.orbe?.supreme});
      observatoryModule.createOwnerObservatoryV532($('#adminApp'),{
        engine,
        orbCore:globalThis.divinaOrbSupremeV501?.core||globalThis.orbe?.supreme,
        completionCore
      });
      return engine;
    }
  });

  const warmers=Object.freeze({
    tarot:()=>Promise.all([
      ensureStyle('divinaTarotLivreOrbOSV517','tarot-livre-orbe-os-v517.css?v=538-fluid'),
      ensureStyle('divinaTarotFreeSupremeV553','tarot-free-supreme-v553.css?v=553'),
      import('./tarot-livre-orbe-os-v517.js?v=576-foundation')
    ]),
    daily:()=>Promise.all([
      ensureStyle('divinaDailyLivingV509','daily-world-v509.css?v=554'),
      ensureStyle('divinaDailySpreadsSupremeV554','daily-spreads-supreme-v554.css?v=554'),
      import('./daily-world-v509.js?v=595-work12-ritual')
    ]),
    library:()=>Promise.all([
      ensureStyle('divinaLibraryRebirthV302','library-world-v302.css?v=555'),
      ensureStyle('divinaPublicLibraryV544','public-library-core-v544.css?v=555'),
      ensureStyle('divinaSchoolLibrarySupremeV555','school-library-supreme-v555.css?v=555'),
      import('./library-world-v302.js?v=555')
    ]),
    spreads:()=>Promise.all([
      ensureStyle('divinaSpreadsRebirthV305','spreads-world-v305.css?v=554'),
      ensureStyle('divinaDailySpreadsSupremeV554','daily-spreads-supreme-v554.css?v=554'),
      import('./spreads-world-v305.js?v=554')
    ]),
    school:()=>Promise.all([
      ensureStyle('divinaSchoolRebirthV306','school-world-v306.css?v=555'),
      ensureStyle('divinaSchoolLibrarySupremeV555','school-library-supreme-v555.css?v=555'),
      import('./school-world-v306.js?v=596-work12-chambers')
    ]),
    journal:()=>Promise.all([
      ensureStyle('divinaJournalRebirthV317','journal-world-v317.css?v=556'),
      ensureStyle('divinaJournalMirrorSupremeV556','journal-mirror-supreme-v556.css?v=556'),
      import('./journal-world-v317.js?v=596-work12-chambers')
    ]),
    ai:()=>Promise.all([
      ensureStyle('divinaWhitPresenceDeepV540','whit-presence-deep-v540.css?v=557'),
      ensureStyle('divinaWhitLocalSupremeV557','whit-local-supreme-v557.css?v=557'),
      import('./ai-engine.js?v=557')
    ]),
    skins:()=>Promise.all([
      ensureStyle('divinaCrownRebirthV318','skins-premium-world-v318.css?v=546'),
      import('./skins-premium-world-v318.js?v=546')
    ]),
    subscriptions:()=>Promise.all([
      ensureStyle('divinaCrownRebirthV318','skins-premium-world-v318.css?v=546'),
      import('./skins-premium-world-v318.js?v=546')
    ]),
    consultations:()=>Promise.all([
      import('./commerce-engine.js?v=148'),
      ensureStyle('divinaAccountConsultationsRebirthV319','account-consultations-world-v319.css?v=319'),
      ensureStyle('divinaConsultationsSupremeV558','consultations-supreme-v558.css?v=558'),
      import('./account-consultations-world-v319.js?v=558-consultations-supreme')
    ]),
    store:()=>Promise.all([
      import('./commerce-engine.js?v=148'),
      ensureStyle('divinaMediaCommerceRebirthV320','media-commerce-world-v320.css?v=320'),
      ensureStyle('divinaAmazonStoreV543','amazon-store-core-v543.css?v=543'),
      import('./media-commerce-world-v320.js?v=543')
    ]),
    music:()=>Promise.all([
      ensureStyle('divinaMusicVideoSupremeV559','music-video-supreme-v559.css?v=559'),
      import('./music-video-supreme-v559.js?v=559')
    ]),
    videos:()=>Promise.all([
      ensureStyle('divinaMusicVideoSupremeV559','music-video-supreme-v559.css?v=559'),
      import('./music-video-supreme-v559.js?v=559')
    ]),
    admin:()=>Promise.all([
      ensureStyle('divinaMediaCommerceRebirthV320','media-commerce-world-v320.css?v=320'),
      ensureStyle('divinaMusicVideoSupremeV559','music-video-supreme-v559.css?v=559'),
      ensureStyle('divinaAdminIntelligenceRebirthV322','admin-intelligence-v322.css?v=322'),
      ensureStyle('divinaOwnerObservatoryV532Styles','owner-observatory-v532.css?v=548'),
      ensureStyle('divinaCompletionCenterV548Styles','completion-center-v548.css?v=548'),
      import('./admin-engine.js?v=548'),
      import('./admin-media-supreme-v559.js?v=559'),
      import('./admin-intelligence-v322.js?v=561'),
      import('./owner-observatory-v532.js?v=548'),
      import('./completion-center-v548.js?v=548')
    ]),
    notifications:()=>Promise.all([
      ensureStyle('divinaNotificationsRebirthV321','notifications-world-v321.css?v=321'),
      import('./notifications-world-v321.js?v=321')
    ])
  });

  const warm=ids=>{
    const list=Array.isArray(ids)?ids:[ids];
    return Promise.allSettled(
      list.filter(id=>warmers[id]).map(id=>once(sharedTasks,`warm:${id}`,warmers[id]))
    );
  };

  const prime=rawId=>{
    const id=normalizeRouteId(rawId);
    if(!routeHasModule(id))return Promise.resolve({id,state:'static'});
    return warmers[id]
      ? once(sharedTasks,`warm:${id}`,warmers[id]).then(()=>({id,state:'warm'}))
      : Promise.resolve({id,state:'on-demand'});
  };

  const load=rawId=>{
    const id=normalizeRouteId(rawId);
    if(!routeHasModule(id)) return Promise.resolve(null);
    const loader=loaders[id];
    if(!loader) return Promise.reject(new Error(`Motor ausente para ${id}`));
    if(id==='tarot'&&pageTasks.has(id)){
      const current=globalThis.divinaTarotLivreV517;
      if(current?.foundationRelease!==576||current.destroyed||current.root!==$('#tarot')){
        pageTasks.delete(id);
      }
    }

    return once(pageTasks,id,async()=>{
      const screen=document.getElementById(id);
      const html=document.documentElement;
      const loadingId=`world:${id}:${++loadingSequence}`;

      clearRecovery(screen);
      screen?.setAttribute('aria-busy','true');
      screen?.setAttribute('data-module-state','loading');
      html.dataset.pageLoading=id;
      announceLoading('start',{
        id:loadingId,
        pageId:id,
        label:routeLabel(id),
        message:LOADING_MESSAGES[id]
      });
      document.dispatchEvent(new CustomEvent('divina:page-loading',{detail:{id}}));

      try{
        const styleTask=routeNeedsPortalStyles(id)?loadPortalStyles():Promise.resolve(null);
        const [,instance]=await Promise.all([
          styleTask,
          withTimeout(loader(),LOAD_TIMEOUT_MS,`Tempo esgotado ao abrir ${routeLabel(id)}.`)
        ]);
        clearRecovery(screen);
        screen?.setAttribute('data-module-state','ready');
        document.dispatchEvent(new CustomEvent('divina:page-ready',{detail:{id}}));
        return instance;
      }catch(error){
        screen?.setAttribute('data-module-state','error');
        createRecovery(screen,id);
        document.dispatchEvent(new CustomEvent('divina:page-error',{detail:{id,recoverable:true}}));
        globalThis.dispatchEvent?.(new CustomEvent('orbe:toast',{
          detail:'Este mundo não abriu agora. Nada foi perdido.'
        }));
        console.error(`[Divina] falha ao abrir ${id}`,error);
        throw error;
      }finally{
        announceLoading('end',{id:loadingId,pageId:id});
        screen?.removeAttribute('aria-busy');
        if(html.dataset.pageLoading===id) delete html.dataset.pageLoading;
      }
    });
  };

  const prepare=rawId=>{
    const id=normalizeRouteId(rawId);
    if(!routeHasModule(id))return Promise.resolve({id,state:'static'});
    const screen=document.getElementById(id);
    if(screen?.getAttribute('data-module-state')==='ready'&&(
      id!=='tarot'||globalThis.divinaTarotLivreV517?.foundationRelease===576
    )){
      return Promise.resolve({id,state:'ready'});
    }
    // Mundos em que a Orbe revela, descobre, continua, escuta ou escreve não
    // admitem alvo provisório: altar e gesto existem antes da rota visível.
    if(ARRIVAL_CRITICAL_ROUTES_V577.has(id)){
      return load(id).then(instance=>({
        id,
        state:'ready-for-arrival',
        deferred:false,
        instance
      }));
    }
    const budget=document.documentElement.dataset.performanceTier==='constrained'
      ? 24
      : NAVIGATION_PREPARE_BUDGET_MS_V535;
    // Nos demais mundos, o altar universal estável já é o destino definitivo;
    // o conteúdo secundário continua entrando pelo orçamento curto.
    const settled=prime(id).then(
      ()=>({id,state:'primed',deferred:true}),
      error=>({id,state:'prime-error',error,deferred:true})
    );
    return Promise.race([
      settled,
      wait(budget).then(()=>({id,state:'priming',deferred:true}))
    ]).then(result=>{
      if(result.deferred){
        document.dispatchEvent(new CustomEvent('divina:page-deferred',{
          detail:Object.freeze({
            id,
            budgetMs:budget,
            release:'V535',
            state:result.state,
            recoverable:true
          })
        }));
      }
      return result;
    });
  };

  const retry=id=>{
    const route=normalizeRouteId(id);
    pageTasks.delete(route);
    clearRecovery(document.getElementById(route));
    const coordinator=globalThis.divinaWork12V592;
    return Promise.resolve(
      coordinator?.navigate
        ? coordinator.navigate(route,{source:'route-retry'})
        : go?go(route):load(route)
    );
  };

  const primeFromIntent=event=>{
    const id=event.target.closest?.('[data-go]')?.dataset.go;
    if(id&&routeHasModule(id)) prime(id).catch(()=>{});
  };

  document.addEventListener('pointerdown',primeFromIntent,{capture:true,passive:true,signal:abort.signal});
  document.addEventListener('focusin',primeFromIntent,{capture:true,signal:abort.signal});
  document.addEventListener('click',primeFromIntent,{capture:true,signal:abort.signal});
  document.addEventListener('click',event=>{
    const button=event.target.closest?.('[data-route-retry]');
    if(!button)return;
    event.preventDefault();
    retry(button.dataset.routeRetry).catch(()=>{});
  },{signal:abort.signal});

  const scheduleLoad=id=>{
    const route=normalizeRouteId(id);
    if(!routeHasModule(route))return;
    deferredRoute=route;
    cancelAnimationFrame(deferredFrame);
    clearTimeout(deferredTimer);
    deferredFrame=requestAnimationFrame(()=>{
      deferredFrame=0;
      deferredTimer=setTimeout(()=>{
        deferredTimer=0;
        const target=deferredRoute;
        deferredRoute=null;
        if(target)load(target).catch(()=>{});
      },0);
    });
  };

  observer=new MutationObserver(()=>{
    const id=document.body.dataset.screen;
    if(!id)return;
    if(document.documentElement.dataset.orbNavigationState==='active'){
      deferredRoute=normalizeRouteId(id);
      return;
    }
    scheduleLoad(id);
  });
  observer.observe(document.body,{attributes:true,attributeFilter:['data-screen']});
  document.addEventListener('divina:supreme-orb-did-navigate',event=>{
    scheduleLoad(event.detail?.to||deferredRoute||document.body.dataset.screen);
  },{passive:true,signal:abort.signal});

  return Object.freeze({
    load,
    prepare,
    prime,
    retry,
    warm,
    go:id=>Promise.resolve(go?go(normalizeRouteId(id)):load(id)),
    portalStylesReady:()=>Boolean(document.getElementById(PORTAL_STYLES_ID)?.sheet),
    navigationPrepareBudgetMs:NAVIGATION_PREPARE_BUDGET_MS_V535,
    destroy:()=>{
      abort.abort();
      observer?.disconnect();
      cancelAnimationFrame(deferredFrame);
      clearTimeout(deferredTimer);
      deferredRoute=null;
    }
  });
}
